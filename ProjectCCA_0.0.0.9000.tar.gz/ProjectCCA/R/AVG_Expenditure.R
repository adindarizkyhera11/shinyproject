#' A function that calculates a mean expenditure of a numeric vectors based on a given group of region
#'
#' The function below calculates the arithmetic mean of the numerical vectors based on a given group of region, ignoring missing values.
#'
#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param region character
#' @return a single numeric value is returned - the total from the input vectors
#' @export

AVG_Expenditure <- function(data,region){
  mydata <- data[data$Region == region,]
  AVGexpend  =  mean(mydata$Total.Food.Expenditure) + mean(mydata$Clothing..Footwear.and.Other.Wear.Expenditure)+
    mean(mydata$Imputed.House.Rental.Value) + mean(mydata$Transportation.Expenditure) +
    mean(mydata$Education.Expenditure)+ mean(mydata$Special.Occasions.Expenditure)+
    mean(mydata$Medical.Care.Expenditure)
  return(AVGexpend)
}