#' A function that calculates a total expenditure of a numeric vector based on a given group of region
#'
#' The function below calculates a total expenditure of a numeric vector based on a given group of region
#'
#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param region character
#' @return a single numeric value is returned - the total from the input vectors
#' @export

Reg_Expenditure <- function(data, region){
  mydata <- data[data$Region == region,]
  total =  sum(mydata$Total.Food.Expenditure) + sum(mydata$Clothing..Footwear.and.Other.Wear.Expenditure)+
        sum(mydata$Imputed.House.Rental.Value) + sum(mydata$Transportation.Expenditure) +
        sum(mydata$Education.Expenditure)+ sum(mydata$Special.Occasions.Expenditure)+
        sum(mydata$Medical.Care.Expenditure)
   return(total)
}