#' A function that returns a plot of how expenditure depends on a given variable of a given data
#' The function below returns a plot of how expenditure depends on a given variable of a given data

#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param var  character 
#' @return a plot of how expenditure depends on a given variable of a given data
#' @export

ExpenditurePlot <- function(data, var){
  varx <- data[, var]
  
  Expenditure <- data$Total.Food.Expenditure + data$Clothing..Footwear.and.Other.Wear.Expenditure +
    data$Imputed.House.Rental.Value + data$Transportation.Expenditure +
    data$Education.Expenditure + data$Special.Occasions.Expenditure +
    data$Medical.Care.Expenditure
  
  if(is.factor(varx)) {
    boxplot(Expenditure ~ varx,
            data = data,
            xlab = var,
            ylab = "Total Expenditure")
  } else if ( is.numeric(varx)){
    plot(x = varx, y = Expenditure,
         xlab = var,
         ylab = "Total Expenditure")
  } else {
    print("No plot")
  }
}