#' A function that calculates a total expenditure of a numeric vector based on a given gender
#'
#' The function below calculates a total expenditure of a numeric vector based on a given gender
#'
#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param sex character
#' @return a single numeric value is returned - the total from the input vectors
#' @export

Gender_Expenditure <- function(data,sex){
  mydata <- data[data$Household.Head.Sex == sex,]
  total =  sum(mydata$Total.Food.Expenditure) + sum(mydata$Clothing..Footwear.and.Other.Wear.Expenditure)+
    sum(mydata$Imputed.House.Rental.Value) + sum(mydata$Transportation.Expenditure) +
    sum(mydata$Education.Expenditure)+ sum(mydata$Special.Occasions.Expenditure)+
    sum(mydata$Medical.Care.Expenditure)
  return(total)
}