#' A function that calculates a mean income of a numeric vectors based on a given group of region
#'
#' The function below calculates the arithmetic mean of the numerical vectors based on a given group of region, ignoring missing values.
#'
#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param region character
#' @return a single numeric value is returned - the total from the input vectors
#' @export

AVG_Income <- function(data, region){
  mydata <- data[data$Region == region,]
  avgincome <- mean(mydata$Total.Household.Income)
 return(avgincome)
}