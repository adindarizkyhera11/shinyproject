#' A function that returns a regresion plot and p-values for a given fomular based on a given data
#' The function below returns a regresion plot and p-values for a given fomular based on a given data
#' @author Cuc NM
#' @param data numeric. numeric vectors
#' @param formula a formula 
#' @return a tables of numeric value and plots is returned - the information of regresion
#' @export

my_reg <- function(formula, data) {
  fit = lm(formula, data)
  par(mfrow=c(1,1)) 
  plot(fit)
  print(summary(fit))
  invisible(fit)
}
